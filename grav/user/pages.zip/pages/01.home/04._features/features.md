---
title: Homepage Features
menu: Features
class: small
features:
    - header: Markdown Syntax
      icon: fa fa-text-height
    - header: Twig Templating
      icon: fa fa-code
    - header: Smart Caching
      icon: fa fa-rocket
    - header: Flexible Taxonomies
      icon: fa fa-tags
    - header: Simple Install
      icon: fa fa-cloud-download
    - header: Powerful Plugins
      icon: fa fa-cogs
    - header: Intuitive UI
      icon: fa fa-dashboard
    - header: File-Based
      icon: fa fa-file-text
    - header: Multi-Language
      icon: fa fa-language
    - header: Users & Roles
      icon: fa fa-users  
    - header: Image Processing
      icon: fa fa-image   
    - header: Documentation
      icon: fa fa-bookmark
    - header: On Github
      icon: fa fa-github
    - header: Responsive Design
      icon: fa fa-html5
    - header: CLI Power
      icon: fa fa-terminal  
    - header: Awesomazing
      icon: fa fa-heart-o
---

# Stuffed Full of Features
## **Check out small smattering...**
